# var_destroy re-entry use-after-free in unserialize() — first demonstration, survives PHP 8.5.12

**Andrew Dorman (@acd421) — 2026-10-21. Status: unfiled. Publicly named as a surviving patch gap ("var_destroy re-entry UAF at n=1015", Wiz companion repo, 2026-10-21) but never demonstrated before this receipt.**

## Finding

A deterministic heap-use-after-free in `php_var_unserialize` on the
fully-patched PHP 8.5.12, triggered by unserializing a single crafted
string. No configuration, no extensions, plain userland.

**Receipt (deterministic, reproduced independently twice — agent run and
coordinator re-run from this exact file):**

```
ERROR: AddressSanitizer: heap-use-after-free on address 0x52500000a100
SUMMARY: heap-use-after-free ext/standard/var_unserializer.c:906 in php_var_unserialize
READ of size 8 ... called from var_destroy (:319) ← i_zval_ptr_dtor ←
zend_objects_store_del ← __destruct ← zend_call_function ←
php_var_unserialize (nested) ← zif_unserialize
```

## Mechanism

`php_unserialize_data` tracks decoded refcounted values in a chain of
`var_entries` blocks holding 1018 slots. `PHP_VAR_UNSERIALIZE_DESTROY`'s
slot walk destroys entries; the `__wakeup`/`__unserialize` delayed calls
are bracketed by `BG(serialize_lock)++/--`, but the **plain
`i_zval_ptr_dtor` on each slot is not** (var_unserializer.c:319).

The PoC (`poc/vd4_wakeup.php`) combines three conditions:

1. **Element count crosses the 1015–1018 slot-block boundary** — the
   payload declares 1018 array elements, forcing the boundary region of
   the entries chain.
2. **An object with both `__wakeup` and `__destruct`**: `__wakeup` earns
   the object a VAR_WAKEUP_FLAG delayed-call slot; `__destruct` calls
   `unserialize('i:7;')` — the re-entry.
3. **A trailing decode error** (missing closing brace): the partial tree
   is freed before destroy runs, making the flagged slot the object's
   last reference — so the `__destruct` fires *during* the destroy walk,
   through the unbracketed dtor.

The nested `unserialize()` executes with `BG(unserialize).level == 1` and
`serialize_lock == 0` — it reuses the mid-destroy context and reads the
already-freed var_entries chain at `var_unserializer.c:906`.

## Honest bounds

- Demonstrated under ASAN (asan2 build: stock php-8.5.12 tarball +
  `-fsanitize=address`). **The identical PoC runs silent on the stock
  non-ASAN build in this shape** — the freed-chain read does not fault a
  stock binary yet.
- CVE-grade CWE-416 as-is (attacker-controlled `unserialize()` input is a
  standard remote surface); stock-build corruption and escalation are
  under active investigation (payload shaping around the boundary slots,
  refcounted values at the freed-chain entries, R:N reference interplay).
- Affects every current release (the var layer is unchanged across the
  8.2–8.5 branches; verified identical in 8.1.2 as well — see
  `vd_versions.log`).

## Fix direction

Bracket the plain slot dtor in `var_destroy` with the same
`serialize_lock` protection used for the delayed-call callbacks (or run
the slot walk with re-entrant unserialize contexts forbidden: treat
`level != 0` during destroy as an error). Additionally, reset the context
chain state before re-entry rather than reusing mid-destroy.

## Credits

- **Finding, trigger recipe, and receipts:** Andrew Dorman (@acd421)
  with Claude (Anthropic) agent tooling, 2026-10-21 (agent
  instrumentation + coordinator re-verification).
- **Gap naming (public record):** Wiz research team companion repo
  ("var_destroy re-entry UAF at n=1015", 2026-10-21) — named but not
  demonstrated there.
- **Root-cause substrate documented earlier:** the php2shell research
  corpus (BG context caching mechanics).

## Reproduce

```
# ASAN build of stock php-8.5.12 (see package README build line, plus
# CFLAGS=-fsanitize=address), then:
USE_ZEND_ALLOC=0 ASAN_OPTIONS=detect_leaks=0 sapi/cli/php -n zero4_var_destroy_uaf/poc/vd4_wakeup.php
```

Raw receipt: `vd4_asan.log`. Cross-version notes: `vd_versions.log`.
